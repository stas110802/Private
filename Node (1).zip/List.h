typedef struct List{
	int data;
	struct List *pNext;
}List;
